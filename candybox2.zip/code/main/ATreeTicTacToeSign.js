var ATreeTicTacToeSign;
(function (ATreeTicTacToeSign) {
    ATreeTicTacToeSign[ATreeTicTacToeSign["NO_SIGN"] = 0] = "NO_SIGN";
    ATreeTicTacToeSign[ATreeTicTacToeSign["X"] = 1] = "X";
    ATreeTicTacToeSign[ATreeTicTacToeSign["O"] = 2] = "O";
})(ATreeTicTacToeSign || (ATreeTicTacToeSign = {}));
//# sourceMappingURL=ATreeTicTacToeSign.js.map