var GiantNougatMonsterStep;
(function (GiantNougatMonsterStep) {
    GiantNougatMonsterStep[GiantNougatMonsterStep["ASLEEP"] = 0] = "ASLEEP";
    GiantNougatMonsterStep[GiantNougatMonsterStep["AWAKE"] = 1] = "AWAKE";
    GiantNougatMonsterStep[GiantNougatMonsterStep["ANGRY"] = 2] = "ANGRY";
})(GiantNougatMonsterStep || (GiantNougatMonsterStep = {}));
//# sourceMappingURL=GiantNougatMonsterStep.js.map