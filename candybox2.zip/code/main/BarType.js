var BarType;
(function (BarType) {
    BarType[BarType["SIMPLE"] = 0] = "SIMPLE";
    BarType[BarType["HEALTH"] = 1] = "HEALTH";
    BarType[BarType["UNICOLOR_HEALTH"] = 2] = "UNICOLOR_HEALTH";
})(BarType || (BarType = {}));
//# sourceMappingURL=BarType.js.map