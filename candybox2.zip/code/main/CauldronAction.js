var CauldronAction;
(function (CauldronAction) {
    CauldronAction[CauldronAction["NOTHING"] = 0] = "NOTHING";
    CauldronAction[CauldronAction["MIXING"] = 1] = "MIXING";
    CauldronAction[CauldronAction["BOILING"] = 2] = "BOILING";
})(CauldronAction || (CauldronAction = {}));
//# sourceMappingURL=CauldronAction.js.map