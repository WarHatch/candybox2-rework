enum CandiesThrownSmileyCaveStep{
    FIRST_ROOM,
    SECOND_ROOM,
    THIRD_ROOM
}