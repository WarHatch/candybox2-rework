var CandiesThrownSmileyCaveObject = /** @class */ (function () {
    // Constructor
    function CandiesThrownSmileyCaveObject(str, position) {
        this.str = str;
        this.position = position;
    }
    // Public getters
    CandiesThrownSmileyCaveObject.prototype.getPosition = function () {
        return this.position;
    };
    CandiesThrownSmileyCaveObject.prototype.getStr = function () {
        return this.str;
    };
    return CandiesThrownSmileyCaveObject;
}());
//# sourceMappingURL=CandiesThrownSmileyCaveObject.js.map