var CandiesThrownSmileyCaveStep;
(function (CandiesThrownSmileyCaveStep) {
    CandiesThrownSmileyCaveStep[CandiesThrownSmileyCaveStep["FIRST_ROOM"] = 0] = "FIRST_ROOM";
    CandiesThrownSmileyCaveStep[CandiesThrownSmileyCaveStep["SECOND_ROOM"] = 1] = "SECOND_ROOM";
    CandiesThrownSmileyCaveStep[CandiesThrownSmileyCaveStep["THIRD_ROOM"] = 2] = "THIRD_ROOM";
})(CandiesThrownSmileyCaveStep || (CandiesThrownSmileyCaveStep = {}));
//# sourceMappingURL=CandiesThrownSmileyCaveStep.js.map