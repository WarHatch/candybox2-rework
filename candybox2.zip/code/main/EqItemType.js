var EqItemType;
(function (EqItemType) {
    EqItemType[EqItemType["WEAPON"] = 0] = "WEAPON";
    EqItemType[EqItemType["HAT"] = 1] = "HAT";
    EqItemType[EqItemType["BODYARMOUR"] = 2] = "BODYARMOUR";
    EqItemType[EqItemType["GLOVES"] = 3] = "GLOVES";
    EqItemType[EqItemType["BOOTS"] = 4] = "BOOTS";
})(EqItemType || (EqItemType = {}));
//# sourceMappingURL=EqItemType.js.map