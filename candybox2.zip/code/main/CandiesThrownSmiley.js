var CandiesThrownSmiley = /** @class */ (function () {
    // Constructor
    function CandiesThrownSmiley() {
    }
    // Public methods
    CandiesThrownSmiley.prototype.draw = function (renderArea, x, y, base) {
        // We're in the mother class, so we just draw nothing and return 0
        return 0;
    };
    return CandiesThrownSmiley;
}());
//# sourceMappingURL=CandiesThrownSmiley.js.map