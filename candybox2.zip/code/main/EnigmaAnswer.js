// We can't use this class directly, we have to use a daughter class
var EnigmaAnswer = /** @class */ (function () {
    // Constructor
    function EnigmaAnswer() {
    }
    // Public methods
    EnigmaAnswer.prototype.isRight = function (answer) {
        return false;
    };
    return EnigmaAnswer;
}());
//# sourceMappingURL=EnigmaAnswer.js.map