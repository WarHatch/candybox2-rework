var BigSharkFinType;
(function (BigSharkFinType) {
    BigSharkFinType[BigSharkFinType["RED"] = 0] = "RED";
    BigSharkFinType[BigSharkFinType["GREEN"] = 1] = "GREEN";
    BigSharkFinType[BigSharkFinType["PURPLE"] = 2] = "PURPLE";
})(BigSharkFinType || (BigSharkFinType = {}));
//# sourceMappingURL=BigSharkFinType.js.map