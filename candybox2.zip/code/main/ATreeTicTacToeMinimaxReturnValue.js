var ATreeTicTacToeMinimaxReturnValue = /** @class */ (function () {
    function ATreeTicTacToeMinimaxReturnValue() {
        this.bestPosition = null;
        this.bestScore = null;
    }
    return ATreeTicTacToeMinimaxReturnValue;
}());
//# sourceMappingURL=ATreeTicTacToeMinimaxReturnValue.js.map