var DemonType;
(function (DemonType) {
    DemonType[DemonType["CUBE"] = 0] = "CUBE";
    DemonType[DemonType["EYES"] = 1] = "EYES";
    DemonType[DemonType["BUBBLES"] = 2] = "BUBBLES";
})(DemonType || (DemonType = {}));
//# sourceMappingURL=DemonType.js.map