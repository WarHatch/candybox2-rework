var GalacticWarsStep;
(function (GalacticWarsStep) {
    GalacticWarsStep[GalacticWarsStep["SPLASH_SCREEN"] = 0] = "SPLASH_SCREEN";
    GalacticWarsStep[GalacticWarsStep["GAME"] = 1] = "GAME";
    GalacticWarsStep[GalacticWarsStep["LOSE"] = 2] = "LOSE";
})(GalacticWarsStep || (GalacticWarsStep = {}));
//# sourceMappingURL=GalacticWarsStep.js.map