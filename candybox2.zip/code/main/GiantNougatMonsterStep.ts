enum GiantNougatMonsterStep{
    ASLEEP,
    AWAKE,
    ANGRY
}